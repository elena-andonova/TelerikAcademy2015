## 01. XML Basics
### [View Presentation online](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html)
### Table of Contents
* What is XML? - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/what-is-xml)
* XML and HTML - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/xml-and-html)
* When to use XML? - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/when-to-use-xml)
* Namespaces - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/namespaces)
* Schemas and validation] - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/xml-schemas-and-validation)
  * DTD and XSD Schemas
* XML Parsers - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/xml-parsers)
* XPath Language - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/xpath)
* XSL Transformations - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/01.%20XML%20Basics/Slides/index.html#/xsl-transformations)