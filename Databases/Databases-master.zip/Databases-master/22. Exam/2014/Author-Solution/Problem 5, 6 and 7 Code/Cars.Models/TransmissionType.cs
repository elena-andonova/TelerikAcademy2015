﻿namespace Cars.Models
{
    public enum TransmissionType
    {
        Manual = 0,
        Automatic = 1,
    }
}