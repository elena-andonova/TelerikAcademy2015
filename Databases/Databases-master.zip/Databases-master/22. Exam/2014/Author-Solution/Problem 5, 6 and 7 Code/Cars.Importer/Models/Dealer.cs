﻿namespace Cars.Importer.Models
{
    public class Dealer
    {
        public string Name { get; set; }

        public string City { get; set; }
    }
}