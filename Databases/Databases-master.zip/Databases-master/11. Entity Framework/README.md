## 11. Entity Framework
### [View Presentation online](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html)
### Table of Contents
*   ORM Technologies – Basic Concepts - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/orm-technologies)
*   Entity Framework – Overview - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/overview-of-ef)
*   Reading Data with EF - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/the-dbcontext-class)
*   Create, Update, Delete using Entity Framework - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/creating-new-data)
*   Extending Entity Classes - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/extending-entity-classes)
*   Executing Native SQL Queries - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/executing-native-sql-queries)
*   Joining and Grouping Tables - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/joining-tables-in-ef)
*   Attaching and Detaching Objects - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/11.%20Entity%20Framework/Slides/index.html#/attaching-and-detaching-objects)
