## 00. Databses - Course Introduction
### [View Presentation online](https://rawgit.com/TelerikAcademy/Databases/master/00.%20Databases%20-%20Course%20Introduction/Slides/index.html)
### Table of Contents
*	What's Coming Next in the Academy? - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/00.%20Databases%20-%20Course%20Introduction/Slides/index.html#/coming-next)
*	The Databases Course Program - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/00.%20Databases%20-%20Course%20Introduction/Slides/index.html#/databases-program)
*	The Trainers Team - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/00.%20Databases%20-%20Course%20Introduction/Slides/index.html#/trainers)
*	Exams and Evaluation - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/00.%20Databases%20-%20Course%20Introduction/Slides/index.html#/evaluation)
*	Resources for the Course - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/00.%20Databases%20-%20Course%20Introduction/Slides/index.html#/resources)