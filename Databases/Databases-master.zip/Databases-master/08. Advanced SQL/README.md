## 08. Advanced SQL
### [View Presentation online](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html)
### Table of Contents
*	Nested SELECT Statements - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/nested-select)
*	Aggregating Data - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/aggregation)
	*	Group Functions and `GROUP BY` - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/3/8)
*	Microsoft SQL Server Functions - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/server-functions)
*	Data Definition Language (DDL) - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/ddl)
*	Creating Tables in MS SQL Server - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/creating-tables)
*	Transactions - [go to slide](https://rawgit.com/TelerikAcademy/Databases/master/08.%20Advanced%20SQL/Slides/index.html#/transactions)
