require("openurl").open("http://localhost:11012/index.html");
