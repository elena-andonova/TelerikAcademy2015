<h1>XML BASICS</h1>

<h2>1.What does the XML language represent? What is it used for?</h2>
<ul>		
<li> It represents structured data, using text with tags.</li>
<li> XML is used to help store, structure, and transfer data</li>
</ul>
<h2>2. What do namespaces represent in an XML document? What are they used for? </h2>
<ul>
<li>XML Namespace represents a mechanism to avoid name conflicts by differentiating elements or attributes within an XML document that may have identical names, but different definitions</li>
<li>They are used for providing uniquely named elements and attributes in an XML document</li>
</ul>
