﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Problem 12. Remove words

    Write a program that removes from a text file all words listed in given another text file.
    Handle all possible exceptions in your methods.

*/
namespace _12.RemoveWords
{
    class RemoveWords
    {
        static void Main(string[] args)
        {
        }
    }
}
