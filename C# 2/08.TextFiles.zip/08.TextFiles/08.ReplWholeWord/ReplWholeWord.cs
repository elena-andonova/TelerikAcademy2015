﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Problem 8. Replace whole word

    Modify the solution of the previous problem to replace only whole words (not strings).
*/
namespace _08.ReplWholeWord
{
    class ReplWholeWord
    {
        static void Main(string[] args)
        {
        }
    }
}
