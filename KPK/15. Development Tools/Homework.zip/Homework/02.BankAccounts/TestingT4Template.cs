﻿
public class Test 
{
			public string TestProperty1 {get;set;}
			public string TestProperty2 {get;set;}
			public string TestProperty3 {get;set;}
	
}