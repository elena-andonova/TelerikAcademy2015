﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
class HighQualityCodeExamPointsProvider
{
    public int GetMyPoints()
    {
        return 0;
    }
    public static string GetContentType()
    {
        return "application/json";
    }
}