﻿// Before deleting this file, uncomment the following code for magic:
/*public class \u0076\u0061\u0072
{
}*/