﻿public interface IResponseProvider
{
    HttpResponse GetResponse(string requestAsString);
}



